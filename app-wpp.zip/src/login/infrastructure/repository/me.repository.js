module.exports = async () => {
    return {
        statusApp,
        qrCodeApp
    }
}